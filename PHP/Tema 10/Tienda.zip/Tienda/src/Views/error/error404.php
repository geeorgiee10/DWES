<hr class="hr">
    <div class="error">
        <h3><?= $titulo?></h3>

        <p>Si quieres volver al inicio pincha aqui</p>
        <a href="<?=  BASE_URL?>">Ir al inicio</a>
    </div>
<hr class="hr">