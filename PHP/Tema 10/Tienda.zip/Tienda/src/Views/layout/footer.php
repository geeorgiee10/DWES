</div>
<footer>
<div id="ayuda">
            <p>Ayuda</p>
            <a>Preguntas Frecuentes</a>
            <a>Centro de Ayuda</a>
            <a>Guia de Usuario</a>
        </div>
        <div id="nosotros">
            <p>Nosotros</p>
            <a>¿Quiénes somo?</a>
            <a>Nuestro Equipo</a>
            <a>Mision y Valores</a>
        </div>
        <div id="legal">
            <p>Legal</p>
            <span> 2024 Fake Web Storage. Todos los derechos reservados.</span>
        </div>
        <div id="pagoYRedes">
            <div id="metodosPago">
                <p>Métodos de pago</p>
                <div id="iconoPago">
                    <i class="fa-solid fa-credit-card"></i>
                    <i class="fa-brands fa-cc-mastercard"></i>
                    <i class="fa-brands fa-cc-paypal"></i>
                </div>
            </div>
            <div id="redesSociales">
                <p>Redes Sociales</p>
                <div id="iconoRedesSociales">
                    <a href="https://www.instagram.com" class="iconos instagram">
                    <i class="fab fa-instagram"></i>
                    </a>
                    <a href="https://www.facebook.com" class="iconos linkedin">
                        <i class="fa-brands fa-square-facebook"></i>
                    </a>
                    <a href="https://twitter.com" class="iconos twitter">
                        <i class="fa-brands fa-x-twitter"></i>
                    </a>
                </div>
        </div>
    </div>
</footer>

</body>
</html>