<?php 
    if(session_status() === PHP_SESSION_NONE){
        session_start();
    }
?>

<div class="guardarCategoria">

<h2>Pago cancelado</h2>


</div>