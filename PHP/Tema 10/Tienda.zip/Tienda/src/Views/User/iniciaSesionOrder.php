<div id="product">


<h2>Debes iniciar sesión</h2>

<p><a href="<?= BASE_URL ?>User/iniciarSesion">Inicia Sesión</a></p>


</div>